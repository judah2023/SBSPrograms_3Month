#include "Weapon.h"

using namespace std;

Weapon::Weapon() : attack(0) {}

void Weapon::Stat()
{
	cout << "���ݷ� : " << attack << endl;
}
