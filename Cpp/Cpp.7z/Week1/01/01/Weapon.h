#pragma once
#include <iostream>

class Weapon
{
private:
	int attack;

public:
	Weapon();
	void Stat();

};
