﻿#pragma once

// 외부 변수
extern int globalValue;