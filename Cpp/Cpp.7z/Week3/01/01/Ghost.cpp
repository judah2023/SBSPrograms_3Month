#include "Ghost.h"

Ghost::Ghost()
{
	SetHP(50);
}

void Ghost::Skill()
{
	std::cout << "Lock Down" << std::endl;
}

