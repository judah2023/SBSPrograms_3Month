﻿#include <iostream>
#include "Sword.h"

using namespace std;

int main()
{

	return 0;
}