#include "Unit.h"

void Unit::SetHP(int const& hp)
{
	this->hp = hp;
}

int Unit::GetHP() const
{
	return hp;
}