#pragma once
#include "Unit.h"
class Ghost : public Unit
{
private:
public:
	Ghost();

	void Skill() override;
};

