#include "Marine.h"

Marine::Marine()
{
	SetHP(100);
}

void Marine::Skill()
{
	std::cout << "SteamPack" << std::endl;
}
