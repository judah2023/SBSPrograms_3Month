#pragma once
#include "Unit.h"
class Marine : public Unit
{
private:
public:
	Marine();

	void Skill() override;
};