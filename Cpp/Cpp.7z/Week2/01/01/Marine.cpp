#include "Marine.h"
#include <iostream>

void Marine::Skill()
{
	std::cout << "SteamPack" << std::endl;
}
