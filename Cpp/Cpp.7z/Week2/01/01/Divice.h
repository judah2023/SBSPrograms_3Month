#pragma once
class Divice
{
public:
	Divice();
};