#include "Divice.h"
#include <iostream>

Divice::Divice()
{
	std::cout << "=================" << std::endl;
	std::cout << "Divice ������ ȣ��" << std::endl;
}
