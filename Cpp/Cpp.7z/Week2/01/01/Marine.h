#pragma once
#include "Unit.h"
class Marine : public Unit
{
public:
	void Skill() override;
};